import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { SubjectService } from '../../services/subject.service';
import { jwtDecode } from "jwt-decode";
import { HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-instructor-subjects',
  standalone: true,
  imports: [CommonModule, MatCardModule, MatButtonModule, MatIconModule],
  templateUrl: './instructor-subjects.component.html',
  styleUrls: ['./instructor-subjects.component.scss']
})

export class InstructorSubjectsComponent implements OnInit {
  subjects: string[] = [];
  loading = true;
  error: string = '';
  constructor(private subjectService: SubjectService, private router: Router) {}

  ngOnInit() {
    const token = localStorage.getItem('token');
    const instructorId = token ? (jwtDecode(token) as any).sub : null;
    if (!instructorId) {
      // اعمل redirect للـ login
      return;
    }

    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });

    this.subjectService.getInstructorSubjects(instructorId, headers).subscribe({
      next: (res) => {
        this.subjects = res || [];
        this.loading = false;
        if (this.subjects.length === 0) {
          this.error = 'لا يوجد مواد لهذا المدرس.';
        }
      },
      error: () => {
        this.error = 'فشل تحميل المواد';
        this.loading = false;
      }
    });
  }

openSubjectDetails(subjectId: string) {
    console.log('Navigating to subject details for:', subjectId);
    this.router.navigate(['/subject-details', subjectId]);  // تأكد من أنك تقوم بالتوجيه إلى المسار الصحيح
  }
}