import { Component } from '@angular/core';
import { AttendanceService } from '../../services/attendance.service';
import { AttendanceStateService } from '../../services/attendance-state.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { Input } from '@angular/core';

@Component({
  selector: 'app-subject-attendance-review',
  templateUrl: './subject-attendance-review.component.html',
  styleUrls: ['./subject-attendance-review.component.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule]
})
export class SubjectAttendanceReviewComponent {
  @Input() subjectId!: string;
  editIndex: number | null = null;
  editName = '';
  editId = '';
  submitted = false;
  message = '';

  constructor(public attendanceService: AttendanceService,
              public attendanceState: AttendanceStateService) {}

 get attendanceList() {
  return this.attendanceState.getReviewList();
}
  startEdit(i: number) {
    this.editIndex = i;
    this.editName = this.attendanceList[i].name;
    this.editId = this.attendanceList[i].id;
  }
  saveEdit() {
    if (this.editIndex !== null) {
      this.attendanceList[this.editIndex] = { name: this.editName, id: this.editId };
      this.editIndex = null;
      this.editName = '';
      this.editId = '';
    }
  }
  remove(i: number) {
    this.attendanceService.removeStudent(i);
  }
 submitAttendance() {
  const students = this.attendanceState.getReviewList(); // أو أي مصدر عندك
const studentIds = students.map(s => s.id); // لو عندك كل student = {name, id}
this.attendanceService.submitAttendance(this.subjectId, studentIds).subscribe({
  next: () => alert('تم تسجيل الحضور!'),
  error: () => alert('خطأ في تسجيل الحضور!')
});

}


  downloadPDF() {
  alert('Download PDF coming soon!');
  // أو نفذ أي منطق إنت عايزه
}

downloadCSV() {
  alert('Download CSV coming soon!');
  // أو نفذ أي منطق إنت عايزه
}

}
