import { Component, Input, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { AttendanceStateService } from '../../services/attendance-state.service';

@Component({
  selector: 'app-subject-attendance',
  standalone: true, 
  templateUrl: './subject-attendance.component.html',
  styleUrls: ['./subject-attendance.component.scss'],
  imports: [
    CommonModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule
  ],
})
export class SubjectAttendanceComponent {
  @Input() subjectId!: string;
  manualName = '';
  manualId = '';

  cameraActive = false;
  stream: MediaStream | null = null;
  capturedImage: string = '';

  @ViewChild('video') video!: ElementRef<HTMLVideoElement>;
  @ViewChild('canvas') canvas!: ElementRef<HTMLCanvasElement>;

  get attendanceList() {
    return this.attendanceState.getDraftList();
  }
  constructor(private attendanceState: AttendanceStateService) {}

  startCamera() {
    this.cameraActive = true;
    setTimeout(() => {
      navigator.mediaDevices.getUserMedia({ video: true }).then((stream) => {
        this.stream = stream;
        this.video.nativeElement.srcObject = stream;
        this.video.nativeElement.play();
      });
    }, 100);
  }

  captureImage() {
    const context = this.canvas.nativeElement.getContext('2d');
    context?.drawImage(this.video.nativeElement, 0, 0, 320, 240);
    this.capturedImage = this.canvas.nativeElement.toDataURL('image/png');
    this.stopCamera();
    // بعد الالتقاط: ممكن هنا تربطها بالـ API أو تضيف للـ draft
    this.attendanceState.addToDraft({ name: 'Student (from face)', id: 'Unknown' }); // Replace this with API call!
    // sendImageToApi() لو هتربط مع الـ API اكتب لي اسم الخدمة 
  }

  stopCamera() {
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = null;
    }
    this.cameraActive = false;
  }

  addManualAttendance() {
    if (this.manualName && this.manualId) {
      this.attendanceState.addToDraft({ name: this.manualName, id: this.manualId });
      this.manualName = '';
      this.manualId = '';
    }
  }

  removeFromAttendance(index: number) {
    this.attendanceState.removeFromDraft(index);
  }
}
