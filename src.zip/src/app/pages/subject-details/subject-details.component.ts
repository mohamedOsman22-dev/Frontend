import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatTabsModule } from '@angular/material/tabs';
import { SubjectStudentsComponent } from './subject-students.component';
import { SubjectAttendanceComponent } from './subject-attendance.component';
import { SubjectAttendanceReviewComponent } from './subject-attendance-review.component';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AttendanceStateService } from '../../services/attendance-state.service';

@Component({
  selector: 'app-subject-details',
  standalone: true,
  imports: [
    CommonModule,
    MatTabsModule,
    SubjectAttendanceComponent,
    SubjectAttendanceReviewComponent,
  ],
  templateUrl: './subject-details.component.html',
  styleUrls: ['./subject-details.component.scss']
})
export class SubjectDetailsComponent implements OnInit {
  
  subjectId!: string;
  subject: any = null;

  constructor(
    private route: ActivatedRoute,
    private http: HttpClient,
    private attendanceState: AttendanceStateService
  ) {}

  ngOnInit(): void {
    this.subjectId = this.route.snapshot.paramMap.get('id')!; // الحصول على المعرف من الراوت
    
    // احصل على التوكن من localStorage
    const token = localStorage.getItem('token');
    
    if (token) {
      // تعيين التوكن في headers
      const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
      
      // إرسال طلب GET باستخدام المعرف والتوكن في الـ headers
      this.http.get(`http://aps.tryasp.net/Instructors//subjects/${this.subjectId}`, { headers })
        .subscribe({
          next: (data) => {
            console.log('Data:', data);
            this.subject = data; // تخزين البيانات في المتغير subject
          },
          error: (err) => {
            console.error('Error:', err);
          }
        });
    } else {
      console.error('No token found'); // في حال عدم وجود التوكن
    }
  }

  sendToReview(): void {
    this.attendanceState.sendDraftToFinal(); // إرسال المسودة للمراجعة
  }

  downloadPDF(): void {
    alert('Download PDF feature coming soon.'); // إظهار رسالة عند محاولة تحميل PDF
  }

  downloadCSV(): void {
    alert('Download CSV feature coming soon.'); // إظهار رسالة عند محاولة تحميل CSV
  }
}
