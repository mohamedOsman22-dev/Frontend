import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AttendanceStateService {
  private draftList: any[] = [];
  private reviewList: any[] = [];

  getDraftList() {
    return this.draftList;
  }

  getReviewList() {
    return this.reviewList;
  }

  // إضافة طالب لدرفت (مع منع التكرار)
  addToDraft(student: any) {
    const exists = this.draftList.some(s => s.id === student.id);
    if (exists) {
      alert('الطالب موجود بالفعل في قائمة الحضور المؤقتة!');
      return false;
    }
    this.draftList.push(student);
    return true;
  }

  // حذف طالب من draft
  removeFromDraft(index: number) {
    this.draftList.splice(index, 1);
  }

  // نقل الطلاب من draft إلى review (مع منع التكرار)
  sendDraftToFinal() {
    let duplicateFound = false;
    this.draftList.forEach(student => {
      const exists = this.reviewList.some(s => s.id === student.id);
      if (exists) {
        duplicateFound = true;
        // مش هنضيف الطالب
      } else {
        this.reviewList.push(student);
      }
    });
    this.draftList = [];
    if (duplicateFound) {
      alert('يوجد طلاب بالفعل في قائمة المراجعة وتم تجاهلهم!');
    }
  }

  // حذف من review
  removeFromReview(index: number) {
    this.reviewList.splice(index, 1);
  }

  // تصفير review بعد الـ submit
  clearReviewList() {
    this.reviewList = [];
  }
}
