export interface Subject {
  id: string;
  name: string;
  description: string;
  startDate: string;
  endDate: string;
  instructorId: string;
} 