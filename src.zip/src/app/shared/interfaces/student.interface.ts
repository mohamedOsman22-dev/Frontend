export interface Student {
  id: string;
  name: string;
  email: string;
  photoUrl?: string;
} 