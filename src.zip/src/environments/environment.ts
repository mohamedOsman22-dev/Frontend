export const environment = {
  production: true,
  apiUrl: 'http://aps.tryasp.net'
};